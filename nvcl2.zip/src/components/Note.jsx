import React from "react";

function Note() {
  return (
    <div className='note'>
      <h1>Javascript and React.js</h1>
      <p>This was an amazing bootcamp taken by sir , we covered everything from scratch</p>
    </div>
    );
}

export default Note;